__version__ = '0.8.0'
git_version = 'a751e1dd128af62f616f9a24504de1b4a0181870'
